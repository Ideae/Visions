fprintf('Running Q1\n');
q1();
pause;

fprintf('Running Q2\n');
q2();

fprintf('Running Q3\n');
q3();
pause;