SeamCarveHelper('ryerson.jpg', 640, 480, 'ryerson_carved1');
pause;
SeamCarveHelper('ryerson.jpg', 720, 320, 'ryerson_carved2');
pause;
SeamCarveHelper('mc_vr.png', 600, 440, 'mc_vr_carved');
pause;